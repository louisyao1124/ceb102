import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit  {
  name = 'Angular';
  apiUrl = 'https://www.techiediaries.com/api/data.json';

  constructor(private httpClient: HttpClient){}

  ngOnInit(){
    this.fetchData();
  }

  private fetchData(){
    const abc = this.httpClient.get(this.apiUrl).toPromise();
    const promise = this.httpClient.get(this.apiUrl).toPromise();
    const promise1 = this.httpClient.get(this.apiUrl).toPromise();
    console.log(promise);  
    promise.then((data)=>{
      // console.log("Promise resolved with: " + JSON.stringify(data));
      console.log("Promise resolved with: " + JSON.stringify(data));
      promise1.then((data)=>{
        console.log("Promise resolved with2: " + JSON.stringify(data));
      }).catch((error)=>{
        console.log("Promise rejected with " + JSON.stringify(error));
       // alert("err"+ JSON.stringify(error));
      });

      // alert(JSON.stringify(data));
      // alert("ok");
    }).catch((error)=>{
      console.log("Promise rejected with " + JSON.stringify(error));
     // alert("err"+ JSON.stringify(error));
    });
  }
}
