import DateTimePicker from '../src/index.js'
new window.Vue({
  el: 'app',
  data: {
  	val: ''
  },
  components: { DatetimePicker }
})