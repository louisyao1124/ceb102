module.exports = {
  extends: [
    'eslint:recommended',
    'plugin:vue/essential'
  ]
}
