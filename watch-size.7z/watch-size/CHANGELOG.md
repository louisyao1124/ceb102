# Changes to Watch Size

### 2.0.0 (June 24, 2018)

- The package now exports to commonjs and es modules, rather than attaching
  itself to `this`.

### 1.0.0 (June 20, 2018)

- Initial version
