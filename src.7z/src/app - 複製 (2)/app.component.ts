import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
//import { Component, OnInit, AfterViewInit } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import {OnInit, AfterViewInit } from '@angular/core'
import * as $ from "jquery";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  name9 = new String("");
  heros = [
    { name: '兩斤勘吉1', age: 35 },
    { name: '秋本麗子', age: 25 },
    { name: '野比大雄', age: 12 },
    { name: '江戶川柯南', age: 8 }
  ];


  title = 'ngmt';
  aa1 = "aab";
  // myModel: string;
  public forecasts: WeatherForecast[] =[];
  forecasts1: WeatherForecast[] =[];
  forecasts2: WeatherForecast[] =[];
  caaa = "aaaaa";
  ca = [];
  // users: Observable<Array<any>>;
  name = 'Angular 6';


  // users: Observable<Array<any>> =[];

  constructor() {

    //this.users = this.http.get<Observable<Array<any>>>('https://jsonplaceholder.typicode.com/users');
  }

  /*
  constructor(private http: HttpClient) {
    this.users = this.http.get<Observable<Array<any>>>
    ('https://jsonplaceholder.typicode.com/users');
  }
  */

  

}




interface WeatherForecast {
  dateFormatted: string;
  temperatureC: number;
  temperatureF: number;
  summary: string;
}

interface WeatherForecast1 {
  dateFormatted: string;
  temperatureC: number;
  temperatureF: number;
  summary: string;
  summary1: WeatherForecast[]; 
}

export interface Todo {
  userId: number;
  id: number;
  title: string;
  completed: boolean;
  editIndex: string;
}
