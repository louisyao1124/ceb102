import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
//import { Component, OnInit, AfterViewInit } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import {OnInit, AfterViewInit } from '@angular/core'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ngmt';
  aa1 = "aab";
  // myModel: string;
  public forecasts: WeatherForecast[] =[];
  forecasts1: WeatherForecast[] =[];
  forecasts2: WeatherForecast[] =[];
  caaa = "aaaaa";
  ca = [];
  // users: Observable<Array<any>>;
  name = 'Angular 6';


  // users: Observable<Array<any>> =[];

  constructor() {

    //this.users = this.http.get<Observable<Array<any>>>('https://jsonplaceholder.typicode.com/users');
  }

  /*
  constructor(private http: HttpClient) {
    this.users = this.http.get<Observable<Array<any>>>
    ('https://jsonplaceholder.typicode.com/users');
  }
  */

  

}




interface WeatherForecast {
  dateFormatted: string;
  temperatureC: number;
  temperatureF: number;
  summary: string;
}

interface WeatherForecast1 {
  dateFormatted: string;
  temperatureC: number;
  temperatureF: number;
  summary: string;
  summary1: WeatherForecast[]; 
}

export interface Todo {
  userId: number;
  id: number;
  title: string;
  completed: boolean;
  editIndex: string;
}
