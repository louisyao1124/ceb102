import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ngmt';
  aa1 = "aab";
  // myModel: string;
  public forecasts: WeatherForecast[] =[];
  caaa = "aaaaa";
  ca = [];

}




interface WeatherForecast {
  dateFormatted: string;
  temperatureC: number;
  temperatureF: number;
  summary: string;
}

interface WeatherForecast1 {
  dateFormatted: string;
  temperatureC: number;
  temperatureF: number;
  summary: string;
  summary1: WeatherForecast[]; 
}


